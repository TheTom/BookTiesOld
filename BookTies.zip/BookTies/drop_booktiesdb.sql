drop database if exists booktiesdb;
