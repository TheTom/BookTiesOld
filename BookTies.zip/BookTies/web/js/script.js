$(function() {
    $(".buy").click(function(){
        var element = $(this);
        var data = element.attr("id");
        var temp = data.split("_");
        var id = temp[1];

        $(".options").hide();
        $("#options_" + id).load("js/buy.jsp?isbn=" + id);
        $("#options_" + id).slideDown();

        /*$.ajax({
            type: "POST",
            url: "buy/browse",
            data: "isbn=" + isbn,
            success: function(sellers) {
                $(".options").hide();
                $("#options_" + isbn).html(sellers);
                $("#options_" + isbn).slideDown();
            }
        });*/

        return false;
    });

    $(".sell").click(function(){
        var element = $(this);
        var data = element.attr("id");
        var temp = data.split("_");
        var id = temp[1];

        $(".options").hide();
        $("#options_" + id).load("js/sell.jsp?isbn=" + id);
        $("#options_" + id).slideDown();

        return false;
    });

    $(".wishlist").click(function(){
        var element = $(this);
        var data = element.attr("id");
        var temp = data.split("_");
        var id = temp[1];

        $(".options").hide();
        $("#options_" + id).load("js/wishlist-add.jsp?isbn=" + id);
        $("#options_" + id).slideDown();
        
        return false;
    });
});