/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

import java.net.URL;

/**
 *
 * @author Alex Robinson
 */
public class PriceInfo implements Comparable
{
    private Float price;
    private String priceUnit;
    private String shipping;
    private String seller;
    private URL site;

    public PriceInfo(Float cost, String priceUnit, String shipping, String seller, URL sellerURL)
    {
        price = cost;
        this.priceUnit = priceUnit;
        this.shipping = shipping;
        this.seller = seller;
        site = sellerURL;
    }

    public Float getPrice()
    {
        return price;
    }

    public String getPriceUnit()
    {
        return priceUnit;
    }

    public String getShipping()
    {
        return shipping;
    }

    public String getSeller()
    {
        return seller;
    }

    public URL getSiteURL()
    {
        return site;
    }

    @Override
    public int compareTo(Object o)
    {
        return price.compareTo(((PriceInfo)o).getPrice());
    }
}
