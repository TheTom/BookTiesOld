// pointless comment
package util;

import business.Books;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alex Robinson, Daniel Shin
 */
public class BookInfo {
    private String title;
    private ArrayList<String> authorNames;
    private ArrayList<String> description;
    private String isbn10;
    private String isbn13;
    private String googleId;
    private URL pictureURL;
    private URL googleSite;

    public BookInfo(String title, ArrayList<String> authorNames,
            ArrayList<String> description, String isbn10, String isbn13,
            String googleId, URL pictureURL, URL googleSite) {
        this.title = title;
        this.authorNames = authorNames;
        this.description = description;
        this.isbn10 = isbn10;
        this.isbn13 = isbn13;
        this.googleId = googleId;
        this.pictureURL = pictureURL;
        this.googleSite = googleSite;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthorNames() {
        String result = "";
        for (int i = 0; i < authorNames.size(); i++) {
            result += authorNames.get(i);
            if (i != authorNames.size() - 1) {
                result += ", ";
            }
        }
        return result;
    }

    public String getDescription() {
        String result = "";
        for (String desc : description)
            result += desc;
        return result;
    }
    
    public String getGoogleID() {
        return googleId;
    }

    public String getPictureURL() {
        if (pictureURL == null)
            return "images/book.jpg";
        return pictureURL.toString();
    }

    /**
     * This function checks if the given check digit is valid.
     * @param partialISBN A partial ISBN that has no check digit.
     * @param checkDigit A check digit for the ISBN.
     * @return Whether or not the check digit is valid.
     */
    public boolean isCheckDigitValid(long partialISBN, int checkDigit)
    {
        int sum = checkDigit;
        for (int i = 2; partialISBN > 0; partialISBN/=10)
            sum += (partialISBN%10)*i++;
        return sum%11==0;
    }

    public String getISBN10()
    {
        return isbn10;
    }

    public String getISBN13()
    {
        return isbn13;
    }

    /**
     * This is used as the book ID in the database
     * The ISBN can be reconstructed from this ID
     * @return The ISBN ID, which is the first nine digits of the ISBN 10
     */
    public int getISBNId() {
        return Integer.parseInt(isbn10.substring(0, isbn10.length() - 1));
    }

    public URL getGoogleSite() {
        return googleSite;
    }

    public Books toBook() {
        List<PriceInfo> prices = PriceScraperUtil.getPricesFromBookInfoThroughGoogle(this);
        double value = Integer.MAX_VALUE;
        for (PriceInfo pi : prices)
            value = Math.min(value, pi.getPrice());
        value = Math.max(value, 2) * .8 + 5;
        if (value == Integer.MAX_VALUE)
            value = 100;

        return new Books(
            getISBNId(),
            getTitle(),
            getAuthorNames(),
            1,
            getPictureURL(),
            (int) value
        );
    }
}
