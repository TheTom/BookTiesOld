package util;

import business.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.security.MessageDigest;
import java.util.Map;
import javax.persistence.Persistence;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author joe
 */
public class BookTiesDB {

    private static EntityManagerFactory emf;
    private EntityManager em;

    /**
     * Create a BookTiesDB instance
     */
    public BookTiesDB() {
        if (emf == null)
            emf = Persistence.createEntityManagerFactory("CS160TeamProject2PU");
        //em = emf.createEntityManager();
    }

    /**
     * Returns combo box html code with all the names of universities in
     * the database
     * @return the String containing the html code for a combo box
     */
    public String getUniversitiesCombo() {
        em = emf.createEntityManager();
        List<business.Universities> list = em.createNamedQuery("Universities.findAll")
            .getResultList();
       String combo = "<select name=\'university\'>";
       for(Universities u : list) {
           combo += "<option value=\'" + u.getId() + "\'>" + u.getName()
              + "</option>";
       }
       combo += "</select>";
       em.close();
       return combo;
    }

    /**
     * Returns combo box html code with all the names of universities in
     * the database with the default option being the university of the user
     * @param user - the user to get the university from
     * @return the String containing the html code for a combo box
     */
    public String getUniversitiesComboDefault(Users user) {
        em = emf.createEntityManager();
        List<Universities> list = em.createNamedQuery("Universities.findAll").getResultList();
        String combo = "<select name=\'university\'>";
        for (Universities u : list) {
            if (user.getUniversities().getName().equals(u.getName())) {
                combo += "<option value=\'" + u.getId() + "\' SELECTED>" + u.getName()
                        + "</option>";
            } else {
                combo += "<option value=\'" + u.getId() + "\'>" + u.getName()
                        + "</option>";
            }
        }
        combo += "</select>";
        em.close();
        return combo;
    }

    /**
     * Adds a new user into the database
     * @param user - the user to add to
     * @return false if there is an exception, true otherwise
     */
    public boolean registerUser(Users user) {
        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(user);
            em.getTransaction().commit();
            em.close();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    /**
     * Update user information
     * @param user - the user to be updated
     * @param email - the email address to update
     * @param address - the address to update
     * @param phone - the phone number to be updated
     * @param university - the university to be updated
     * @return false if there is an exception, true otherwise
     */
    public boolean updateUser(Users user, String email, String address,
            String phone, String university) {
        int college = Integer.parseInt(university);
        boolean success = false;

        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Users updated = em.find(business.Users.class, user.getId());
            if (!email.equals(user.getEmail())) {
                updated.setEmail(email);
            } if (!address.equals(user.getAddress())) {
                updated.setAddress(address);
            } if (!phone.equals(user.getPhone())) {
                updated.setPhone(phone);
            } if (college != user.getUniversities().getId()) {
                List<Universities> list = em.createNamedQuery("Universities.findAll")
                        .getResultList();
                for (Universities u : list) {
                    if (u.getId() == college) {
                        updated.setUniversities(u);
                    }
                }
            }
            em.getTransaction().commit();
            success = true;
        } catch (Exception ex) {
        }
        finally {
            em.close();
            return success;
        }
    }

    /**
     * Change the password of a user
     * @param userId - the id of the user
     * @param user - the name of the user
     * @param email - the email of the user
     * @param newpass - the new password to change to
     * @return false if there is an exception, true otherwise
     */
    public boolean changePassword(int userId, String user, String email, String newpass) {
        boolean success = false;
        MessageDigest md;

        em = emf.createEntityManager();
        try {
            md = MessageDigest.getInstance("SHA-256");
            md.update(newpass.getBytes());
            String mpwd = asHex(md.digest());
            em.getTransaction().begin();
            Users found = em.find(business.Users.class, userId);
            if (found.getName().equals(user) && found.getEmail().equals(email)) {
                found.setPassword(mpwd);
                em.getTransaction().commit();
                success = true;
            }
            else {
                throw new Exception();
            }
        } catch (Exception ex) {
            return success;
        }
        finally {
            em.close();
            return success;
        }
    }

    /**
     * Find a user by id
     * @param id user id
     * @return found user or null
     */
    public Users getUserById(int id) {
        Users user;

        em = emf.createEntityManager();
        try {
            user = (business.Users)em.createNamedQuery("Users.findById")
                .setParameter("id", id).getSingleResult();
        } catch(javax.persistence.NoResultException e) {
            user = null;
        }
        em.close();
        return user;
    }

    /**
     * Find a user by name
     * @param id user id
     * @return found user or null
     */
    public Users getUserByName(String name) {
        Users user;

        em = emf.createEntityManager();
        try {
            user = (business.Users) em.createNamedQuery("Users.findByName")
                .setParameter("name", name).getSingleResult();
        } catch(javax.persistence.NoResultException e) {
            user = null;
        }
        em.close();
        return user;
    }

    /**
     * Find a user by email
     * @param id user id
     * @return found user or null
     */
    public Users getUserByEmail(String email) {
        Users user;

        em = emf.createEntityManager();
        try {
            user = (business.Users) em.createNamedQuery("Users.findByEmail")
                .setParameter("email", email).getSingleResult();
        } catch(javax.persistence.NoResultException e) {
            user = null;
        }
        em.close();
        return user;
    }

    public boolean addBook(Books book) {
        boolean success = false;

        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(book); // use em.merge(book) instead of persist() to update existing objects
            em.getTransaction().commit();
            success = true;
        } catch (Exception ex) {
            return success;
        } finally {
            em.close();
            return success;
        }
    }

    public Books getBookById(int id) {
        Books book;
        em = emf.createEntityManager();
        try {
            book = (business.Books) em.createNamedQuery("Books.findById")
                .setParameter("id", id).getSingleResult();
        } catch(javax.persistence.NoResultException e) {
            book = null;
        }
        em.close();
        return book;
    }

    public List<Listings> getAllListings() {
        List<Listings> listingsFound = null;
        em = emf.createEntityManager();
        try {
            
            listingsFound = (List<Listings>)em.createNamedQuery("Listings.findAll").getResultList();
        } catch(javax.persistence.NoResultException e) {
            listingsFound = null;
        }
        em.close();
        return listingsFound;
    }

    public boolean addMeetups(Meetups meetup) {
        boolean success = false;

        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(meetup);
            em.getTransaction().commit();
            success = true;
        } catch (Exception ex) {
        } finally {
            em.close();
            return success;
        }
    }

    public boolean addListings(Users user, Listings listing) {
        boolean success = false;

        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(listing);
            em.getTransaction().commit();
            Users refreshUser = em.find(business.Users.class, user.getId());
            em.refresh(refreshUser);
            em.detach(refreshUser);
            user.setListingsList(refreshUser.getListingsList());
            success = true;
        } catch (Exception ex) {
            return success;
        } finally {
            em.close();
            return success;
        }
    }

    public Universities getUniversityById(int id) {
        Universities uni;

        em = emf.createEntityManager();
        try {
            uni = (business.Universities) em.createNamedQuery("Universities.findById")
                .setParameter("id", id).getSingleResult();
        } catch(javax.persistence.NoResultException e) {
            uni = null;
        }
        em.close();
        return uni;
    }

    /*
     * 
     */
    /*public List<Listings> getListingsByBook(Books book) {
        List<Listings> list;

        em = emf.createEntityManager();
        try {
            list = (List<Listings>) em.createNamedQuery("Listings.findByBook")
                    .setParameter("books", book).getResultList();
        } catch(javax.persistence.NoResultException e) {
            list = null;
        }
        em.close();
        return list;
    }*/
    /**
     * Add wishlist item to database
     * @param user an existing user
     * @param wish a newly constructed (non persisted) object
     */
    public boolean addToWishlist(Users user, Books book, int price, int semester) {
        boolean success = false;
        try {
            Wishlists wish = new Wishlists();
            wish.setUsers(user);
            wish.setBooks(book);
            wish.setPrice(price);
            wish.setSemester(semester);
            em = emf.createEntityManager();
            em.getTransaction().begin();
            em.persist(wish);
            em.getTransaction().commit();
            Users refreshUser = em.find(business.Users.class, user.getId());
            em.refresh(refreshUser);
            em.detach(refreshUser);
            user.setWishlistsList(refreshUser.getWishlistsList());
            success = true;
        } catch (Exception e) {
            user.setName(e + "");
        } finally {
            em.close();
            return success;
        }
    }

    /**
     * Edit wishlist items for a user
     * @param user the current user, creator of the wishlist items
     * @param deleteIDs ids of the wishlist items to delete
     * @param prices a map of wishlist item ids to prices
     * @param semesters a map of wishlist item ids to semesters
     * @return
     */
    public boolean editWishlist(Users user, List<Integer> deleteIDs, Map<Integer, Integer> prices, Map<Integer, Integer> semesters) {
        boolean success = false;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            for (int deleteID : deleteIDs) {
                em.remove(em.find(business.Wishlists.class, deleteID));
                prices.remove(deleteID);
                semesters.remove(deleteID);
            }
            for (int wishlistID : prices.keySet()) {
                Wishlists wishlist = em.find(business.Wishlists.class, wishlistID);
                wishlist.setPrice(prices.get(wishlistID));
            }
            for (int wishlistID : semesters.keySet()) {
                Wishlists wishlist = em.find(business.Wishlists.class, wishlistID);
                wishlist.setSemester(semesters.get(wishlistID));
            }
            em.getTransaction().commit();
            Users refreshUser = em.find(business.Users.class, user.getId());
            em.refresh(refreshUser);
            em.detach(refreshUser);
            user.setWishlistsList(refreshUser.getWishlistsList());
            success = true;
        } catch (Exception e) {
        } finally {
            em.close();
            return success;
        }
    }


    public boolean editBooks(Users user, ArrayList<Integer> deletes, HashMap<Integer, Integer> prices) {
        boolean success = false;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            for (int deleteID : deletes) {
                em.remove(em.find(business.Listings.class, deleteID));
                prices.remove(deleteID);
            }
            for (int listID : prices.keySet()) {
                Listings listing = em.find(business.Listings.class, listID);
                listing.setPrice(prices.get(listID));
            }
            em.getTransaction().commit();
            Users refreshUser = em.find(business.Users.class, user.getId());
            em.refresh(refreshUser);
            em.detach(refreshUser);
            user.setListingsList(refreshUser.getListingsList());
            success = true;
        } catch (Exception e) {
        } finally {
            em.close();
            return success;
        }
    }

    public boolean addToEqueue(Equeue eq) {
        boolean success = false;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            em.persist(eq);
            em.getTransaction().commit();
            success = true;
        } catch (Exception ex) {
            return success;
        } finally {
            em.close();
            return success;
        }
    }

    public Listings getListingsById(int id) {
        Listings listings;
        em = emf.createEntityManager();
        try {
            listings = (business.Listings)em.createNamedQuery("Listings.findById")
                .setParameter("id", id).getSingleResult();
        } catch(javax.persistence.NoResultException e) {
            listings = null;
        }
        em.close();
        return listings;
    }

    public boolean addToMeetups(Meetups meetup) {
        boolean success = false;
        try {
            // persist the meetup object
            em = emf.createEntityManager();
            em.getTransaction().begin();
            em.persist(meetup);
            em.getTransaction().commit();
            // propogate the change to the buyer object
            Users buyer = meetup.getBuyer();
            buyer.setMeetupsAsSellerList(buyer.getMeetupsAsBuyerList());
            em.getTransaction().begin();
            em.merge(buyer);
            em.getTransaction().commit();
            // propogate the change to the seller object
            Users seller = meetup.getSeller();
            seller.setMeetupsAsBuyerList(seller.getMeetupsAsSellerList());
            em.getTransaction().begin();
            em.merge(seller);
            em.getTransaction().commit();

            success = true;
        } catch (Exception ex) {
            return success;
        } finally {
            em.close();
            return success;
        }
    }

    public boolean editMeetups(Users user, ArrayList<Integer> deletes, 
            HashMap<Integer, Integer> prices, HashMap<Integer, Integer> semesters,
            HashMap<Integer, String> states, HashMap<Integer, String> comments) {
        boolean success = false;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            for (int deleteID : deletes) {
                Meetups found = em.find(business.Meetups.class, deleteID);
                if( found != null ) {
                    em.remove(found);
                    prices.remove(deleteID);
                    semesters.remove(deleteID);
                }
            }
            for (int meetupID : prices.keySet()) {
                Meetups meetup = em.find(business.Meetups.class, meetupID);
                meetup.getListings().setPrice(prices.get(meetupID));
            }
            for (int meetupID : semesters.keySet()) {
                Meetups meetup = em.find(business.Meetups.class, meetupID);
                meetup.getListings().setSemester(semesters.get(meetupID));
            }
            if (!states.isEmpty()) {
                for (int meetupID : states.keySet()) {
                    Meetups meetup = em.find(business.Meetups.class, meetupID);
                    if (states.get(meetupID) == null) {
                        states.put(meetupID, meetup.getState());
                    }
                    meetup.setState(states.get(meetupID));
                }
            }
            if (!comments.isEmpty()) {
                for (int meetupID : comments.keySet()) {
                    if (!comments.get(meetupID).equals("")){
                        Meetups meetup = em.find(business.Meetups.class, meetupID);
                        meetup.setInfo(meetup.getInfo() + ":::" + user.getName()
                            + "::" + comments.get(meetupID));
                    }
                }
            }
            em.getTransaction().commit();
            user.setMeetupsAsBuyerList(user.getMeetupsAsBuyerList());
            success = true;
        } catch (Exception e) {
            System.out.println( "Exception while editing meetups: " + e );
        } finally {
            em.close();
            return success;
        }
    }

    public List<Meetups> getMeetupsByUser(Users user) {
        List<Meetups> list;

        em = emf.createEntityManager();
        try {
            list = (List<Meetups>) em.createNamedQuery("Meetups.findByUser")
                    .setParameter("buyer", user).getResultList();
        } catch(javax.persistence.NoResultException e) {
            list = null;
        }
        em.close();
        return list;
    }

    public List<Meetups> getMeetupsBySeller(Users user) {
        List<Meetups> list;

        em = emf.createEntityManager();
        try {
            list = (List<Meetups>) em.createNamedQuery("Meetups.findBySeller")
                    .setParameter("seller", user).getResultList();
        } catch(javax.persistence.NoResultException e) {
            list = null;
        }
        em.close();
        return list;
    }
    /**
     * Converts a byte array to hexadecimal String
     * @param buf - the array to convert to hex
     * @return the String containing the hexadecimal values
     */
    public static String asHex(byte[] buf) {
        StringBuilder builder = new StringBuilder(buf.length * 2);
        for (int i = 0; i < buf.length; i++) {
            if (((int) buf[i] & 0xff) < 0x10) {
                builder.append("0");
            }
            builder.append(Long.toString((int) buf[i] & 0xff, 16));
        }
        return builder.toString();
    }
}
