package util;

import java.util.Calendar;

/**
 * Utility for working with semesters represented as (year, semester) integers
 * @author Kristopher Windsor
 */
public class SemesterUtil {
    private static String[] seasons = {"Spring", "Summer", "Fall", "Winter"};

    // pseudo constants

    public static int getYearLowerbound() {
        return Calendar.getInstance().get(Calendar.YEAR) - 1;
    }

    public static int getYearUpperbound() {
        return Calendar.getInstance().get(Calendar.YEAR) + 2;
    }

    // forms

    public static String getSelector(String name) {
        return getSelector(name, 0);
    }
    
    public static String getSelector(String name, int preselect) {
        StringBuilder r = new StringBuilder();
        
        preselect = validate(preselect);
        
        for (int i = getYearLowerbound(); i <= getYearUpperbound(); i++)
            for (int j = 0; j < 4; j++) {
                r.append("<option value=\"").append(i * 10 + j).append("\"");
                if (i * 10 + j == preselect)
                    r.append(" selected=\"selected\"");
                r.append(">").append(getLabel(i * 10 + j)).append("</option>");
            }
        
        return "<select name=\"" + name + "\">" + r.toString() + "</select>";
    }
    
    public static String getLabel(int semester) {
        int year = semester / 10;
        int season = semester % 10;
        return seasons[season] + " " + year + (season == 3 ? "-" + (++year % 100) : "");
    }

    // validation

    public static boolean isValid(int semester) {
        int year = semester / 10;
        int season = semester % 10;
        return year >= getYearLowerbound() && year <= getYearUpperbound() && season >= 0 && season < 4;
    }

    public static int validate(int semester) {
        if (isValid(semester))
            return semester;
        return getYearLowerbound() * 10;
    }
}
