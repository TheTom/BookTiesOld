package util;

import business.Users;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author joe
 */
public class CookieUtil {
    /**
     * Gets the User from cookies (only useful when the user is not in the session)
     * @return user from cookies or null
     */
    public static Users getUser(HttpServletRequest request) {
        int id = 0;
        String password = null;
        Cookie[] cookies = request.getCookies();

        if (cookies != null)
            for (Cookie cookie : cookies)
                if (cookie.getName().equals("userid"))
                    id = Integer.parseInt(cookie.getValue());
                else if (cookie.getName().equals("password"))
                    password = cookie.getValue();

        if (id > 0) {
            BookTiesDB btdb = new BookTiesDB();
            Users user = btdb.getUserById(id);
            if (user != null && user.getPassword().equals(password))
                return user;
        }

        return null;
    }

    /**
     * Set cookies to save the logged in user (keep user logged in for 10 years)
     * This should only be called when the user is logged in
     * @param user the user who is logged in
     */
    public static void setUser(HttpServletResponse response, Users user) {
        Cookie id = new Cookie("userid", user.getId() + "");
        Cookie password = new Cookie("password", user.getPassword());
        id.setMaxAge(10 * 365 * 24 * 60 * 60);
        password.setMaxAge(10 * 365 * 24 * 60 * 60);
        response.addCookie(id);
        response.addCookie(password);
    }

    public static void deleteCookie(HttpServletRequest request,
        HttpServletResponse response) {

        if (request.getCookies() != null)
            for (Cookie cookie : request.getCookies())
                if (cookie.getName().equals("userid") || cookie.getName().equals("password")) {
                    cookie.setMaxAge(0);
                    cookie.setValue("");
                    response.addCookie(cookie);
                }
    }
}
