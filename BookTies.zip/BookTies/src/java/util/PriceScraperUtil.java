package util;

import java.util.ArrayList;
import java.util.List;
import com.google.api.gbase.client.*;
import com.google.gdata.util.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.NumberFormat;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author Kristopher Windsor, Alex Robinson, Daniel Shin
 */
public class PriceScraperUtil
{
    static GoogleBaseService baseService = new GoogleBaseService("Book Ties");
    static HashMap<BookInfo, ArrayList<PriceInfo>> cache = new HashMap<BookInfo, ArrayList<PriceInfo>>();

    /**
     * This function gets a google base feed from a string.
     * @param str The string to query google base with.
     * @return The google base feed retrieved. (It could be null)
     */
    private static GoogleBaseFeed getGoogleBaseFeedByString(String str)
    {
        try
        {
            GoogleBaseQuery query =
              new GoogleBaseQuery(FeedURLFactory.getDefault().getSnippetsFeedURL());
            query.setGoogleBaseQuery(str);
            //query.setMaxResults(N);
            //You can change query's maximum results by changing this line's
            //N to a number and uncommenting it.
            return baseService.query(query);
        }
        catch (IOException e)
        {
            return null;
        }
        catch (ServiceException e)
        {
            return null;
        }
    }

    /**
     * This performs a query using a BookInfo object and searches for prices for it.
     * @param bi The BookInfo object.
     * @return A list of prices for the BookInfo.
     */
    public static List<PriceInfo> getPricesFromBookInfoThroughGoogle(BookInfo bi)
    {
        ArrayList<PriceInfo> prices = cache.get(bi);
        if (prices != null)
            return prices;
        prices = new ArrayList<PriceInfo>();
        GoogleBaseFeed gbf = getGoogleBaseFeedByString(
                "[price(float USD)]" +
                "([isbn:\"" + bi.getISBN10() +
                "\" | \"" + bi.getISBN13() +
                "\"])");
        if (gbf == null || gbf.getEntries().isEmpty()) {
            cache.put(bi, prices);
            return prices;
        }
        for (GoogleBaseEntry gbe : gbf.getEntries())
        {
            GoogleBaseAttributesExtension gbas = gbe.getGoogleBaseAttributes();
            if (gbas.getPrice() != null && gbe.getHtmlLink() != null
                    && gbas.getPrice().getUnit().equals("usd"))
            {
                NumberUnit<Float> price = gbas.getPrice();
                Float cost = price.getValue();
                String ctype = price.getUnit();
                String shipping = gbas.getShipping().toString();
                String seller = "";
                URL siteURL = null;
                try
                {
                    if (gbe.getAuthors() != null && gbe.getAuthors().get(0) != null)
                        seller = gbe.getAuthors().get(0).getName();
                    siteURL = new URL(gbe.getHtmlLink().getHref());
                }
                catch (MalformedURLException e)
                {
                    //bad entry erase it
                    continue;
                }
                prices.add(new PriceInfo(cost, ctype, shipping, seller, siteURL));
            }
        }
        Collections.sort(prices);
        cache.put(bi, prices);
        return prices;
    }

    /**
     * Gets the price summary of a given BookInfo containing the lowest price
     * and number of sellers found
     * @param bi the BookInfo
     * @return the price summary
     */
    public static String getPriceSummary(BookInfo bi)
    {
        List<PriceInfo> prices = getPricesFromBookInfoThroughGoogle(bi);
        if (!prices.isEmpty())
        {
            NumberFormat nf = NumberFormat.getInstance();
            nf.setMinimumFractionDigits(2);
            nf.setGroupingUsed(false);
            String lowestPrice = nf.format(prices.get(0).getPrice());
            return "$" + lowestPrice + " from " + prices.size() + " sellers";
        }
        return "No sellers found";
    }
}
