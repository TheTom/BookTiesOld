/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Before a request is processed, make sure we have the user in the session
 * @author Kristopher Windsor
 */
public class SessionUtil {
    /**
     * persists login from cookies
     */
    public static void persistLogin(HttpServletRequest request, HttpServletResponse response) {
        request.setAttribute("user", CookieUtil.getUser(request));
        /*HttpSession session = request.getSession(true);
        if (session.getAttribute("user") == null) {
            session.setAttribute("user", CookieUtil.getUser(request));
            if (session.getAttribute("user") != null)
                request.setAttribute("goodMessage", "Welcome back to Book Ties!");
        }*/
    }

    /**
     * persists login from cookies or redirects if not logged in
     * @return true iif the redirect happens
     */
    public static boolean requireLogin(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        persistLogin(request, response);
        /*if (request.getSession().getAttribute("user") == null) {
            request.setAttribute("badMessage", "You must login to view this page");
            response.sendRedirect("/BookTies/login.jsp");
            return true;
        }*/
        if (request.getAttribute("user") == null) {
            request.setAttribute("badMessage", "You must login to view this page");
            response.sendRedirect("/BookTies/login.jsp");
            return true;
        }
        return false;
    }

}
