package util;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.google.gdata.client.books.*;
import com.google.gdata.data.*;
import com.google.gdata.data.books.*;
import com.google.gdata.data.dublincore.*;
import java.net.URL;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;

/**
 *
 * @author Alex Robinson, Kristopher Windsor, Daniel Shin
 */
public class BookInfoScraper extends HttpServlet
{
    static BooksService service = new BooksService("Book Ties");

    /**
     * This function does a book search for a given string.
     * It does not return null, ever.
     * @param str The string to search for.
     * @return A volumeFeed of all the books.
     */
    public static VolumeFeed searchForBooksWithGoogle(String str)
    {
        try
        {
            VolumeQuery query = new VolumeQuery(new URL("http://www.google.com/books/feeds/volumes"));
            query.setMinViewability(VolumeQuery.MinViewability.NONE);
            query.setFullTextQuery(str);
            query.setMaxResults(50); //change 50 to whatever your heart desires
            return service.query(query, VolumeFeed.class);
        }
        catch (java.net.MalformedURLException e)
        {
            return new VolumeFeed();
        }
        catch (java.io.IOException e)
        {
            return new VolumeFeed();
        }
        catch (com.google.gdata.util.ServiceException e)
        {
            return new VolumeFeed();
        }
    }

    /**
     * This function gets a listing of "bookInfo"s for a group of books found with a search string.
     * @param str The search string to find a book with.
     * @return The list of bookInfo's.
     */
    public static List<BookInfo> getBookListingByGoogle(String str)
    {
        ArrayList<BookInfo> booksFound = new ArrayList<BookInfo>();
        VolumeFeed vf = searchForBooksWithGoogle(str);//.getEntries();
        for (VolumeEntry ent : vf.getEntries())
        {
            String title = "";
            ArrayList<String> authorNames = new ArrayList<String>();
            ArrayList<String> description = new ArrayList<String>();
            URL pictureURL = null;
            URL googleSite = null;
            String googleId = "";
            String isbn10 = null;
            String isbn13 = null;
            for (Title t : ent.getTitles())
                title += t.getValue() + "\n";
            for (Creator c : ent.getCreators())
                authorNames.add(c.getValue());
            for (Description d : ent.getDescriptions())
                description.add(d.getValue());
            for (Link l : ent.getLinks())
            {
                if (l.getType().equals("image/x-unknown"))
                {
                    try
                    {
                        pictureURL = new URL(l.getHref());
                    }
                    catch (java.net.MalformedURLException e)
                    {
                        pictureURL = null;
                    }
                }
            }
            try
            {
                googleSite = new URL(ent.getHtmlLink().getHref());
            }
            catch (java.net.MalformedURLException e)
            {
                googleSite = null;
            }
            if (ent.getIdentifiers().size() > 0)
            {
                googleId = ent.getIdentifiers().get(0).getValue();
                if (ent.getIdentifiers().size() > 1)
                {
                    if (ent.getIdentifiers().get(1).getValue().substring(0, 5).equals("ISBN:"))
                    {
                        isbn10 = ent.getIdentifiers().get(1).getValue().substring(5);
                    }
                    if (ent.getIdentifiers().size() > 2)
                    {
                        if (ent.getIdentifiers().get(2).getValue().substring(0, 5).equals("ISBN:"))
                        {
                            isbn13 = ent.getIdentifiers().get(2).getValue().substring(5);
                        }
                    }
                }
            }

            if (isbn13 != null && isbn10 != null)
            booksFound.add(new BookInfo(title, authorNames, description, isbn10,
                    isbn13, googleId, pictureURL, googleSite));
        }
        return booksFound;
    }


    public static BookInfo getBook(String isbn)
    {
        return getBookListingByGoogle("isbn:" + isbn).get(0);
        /*
        ServletContext application = this.getServletContext();
        BookInfo book = (BookInfo) application.getAttribute(isbn);
        if (book == null) {
            book = getBookListingByGoogle("isbn:" + isbn).get(0);
            application.setAttribute(isbn, book);
        }
        return book;
        */
    }
}
