package servlet.buy;

import business.Books;
import business.Listings;
import business.Users;
import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.BookInfo;
import util.BookInfoScraper;
import util.BookTiesDB;
import util.SemesterUtil;
import util.SessionUtil;

/**
 *
 * @author Kristopher Windsor
 */
public class ListingServlet extends HttpServlet {
   

    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("home.jsp");
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        if (SessionUtil.requireLogin(request, response))
            return;

        Users user = (Users) request.getAttribute("user");
        String isbn = (String)request.getParameter("isbn");
        int price = Integer.parseInt((String)request.getParameter("price"));
        int qty = Integer.parseInt((String)request.getParameter("qty"));
        String condition = (String)request.getParameter("condition");
        String comments = (String)request.getParameter("comments");

        //Add Listing
        BookInfo bi = null;
        BookTiesDB db = new BookTiesDB();
        Books book = db.getBookById(Integer.parseInt(isbn));
        if (book == null) {
            bi = BookInfoScraper.getBook(isbn);
            book = bi.toBook();
        }
        int semester = Integer.parseInt(request.getParameter("semester"));
        Listings listing = new Listings();
        listing.setUsers(user);
        listing.setBooks(book);
        listing.setSemester(semester);
        listing.setPrice(price);
        listing.setState("listed");
        listing.setInfo(comments);
        listing.setBuyer(user);
        listing.setPosttime(new Date());
        listing.setExpiretime(new Date());
        if (price < 0 || !SemesterUtil.isValid(semester) || !db.addListings(user, listing)) {
            request.setAttribute("badMessage", "Error, cannot add your book");
            getServletContext().getRequestDispatcher("/my/books.jsp?isbn=" + book.getId()).forward(request, response);
        } else {
            request.setAttribute("goodMessage", "Book added");
            getServletContext().getRequestDispatcher("/my/books.jsp").forward(request, response);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
