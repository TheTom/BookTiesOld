package servlet;

import business.Users;
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.*;
import java.security.MessageDigest;
import util.BookTiesDB;
import util.CookieUtil;
import util.SessionUtil;

/**
 *
 * @author Joe Orozco, Kristopher Windsor
 */
public class LoginServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("home.jsp");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String password = request.getParameter("pwd");

        SessionUtil.persistLogin(request, response);

        try {
            BookTiesDB btdb = new BookTiesDB();
            Users user = btdb.getUserByName(request.getParameter("user"));
            if (user == null)
                throw new Exception();

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(password.getBytes());
            if (!asHex(md.digest()).equals(user.getPassword()))
                throw new Exception();

            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            try {
                CookieUtil.setUser(response, user);
                response.sendRedirect("home.jsp");
            } catch(Exception ex ) {
                request.setAttribute("badMessage", "Error!");
                getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
            }
        }  catch (Exception e) {
            request.setAttribute("badMessage", "Invalid username or password");
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    public static String asHex(byte buf[]) {
        StringBuilder builder = new StringBuilder(buf.length * 2);
        int i;

        for (i = 0; i < buf.length; i++) {
            if (((int) buf[i] & 0xff) < 0x10)
                builder.append("0");
            builder.append(Long.toString((int) buf[i] & 0xff, 16));
        }

        return builder.toString();
    }

}
