package servlet.my;

import business.Listings;
import business.Meetups;
import business.Users;
import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.BookTiesDB;
import util.SessionUtil;

/**
 *
 * @author Joe
 */
public class MeetupsServlet extends HttpServlet {

    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("home.jsp");
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (SessionUtil.requireLogin(request, response))
            return;

        Users user = (Users) request.getAttribute("user");
        int listingID = 0;
        try {
            listingID = Integer.parseInt((String)request.getParameter("listing_id"));
        } catch (NumberFormatException ex) {
            response.sendRedirect("home.jsp");
        }
        BookTiesDB btdb = new BookTiesDB();
        Listings listing = btdb.getListingsById(listingID);
        Meetups meetup = new Meetups();
        meetup.setListings(listing);
        meetup.setBuyer(user);
        meetup.setSeller(listing.getUsers());
        meetup.setState("proposed");
        meetup.setTime(new Date());
        meetup.setInfo(user.getName() + "::" + (String)request.getParameter("comments"));

        if (!btdb.addToMeetups(meetup)) {
            request.setAttribute("badMessage", "Error, cannot add meetup");
        } else {
            request.setAttribute("goodMessage", "Meetup added");
        }
        getServletContext().getRequestDispatcher("/my/meetups.jsp").forward(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
