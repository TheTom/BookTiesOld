/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servlet.my;

import business.Books;
import business.Users;
import business.Wishlists;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.BookTiesDB;
import util.SemesterUtil;
import util.SessionUtil;

/**
 *
 * @author Kristopher Windsor
 */
public class WishlistServlet extends HttpServlet {
   
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("home.jsp");
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        if (SessionUtil.requireLogin(request, response))
            return;
        
        Users user = (Users) request.getAttribute("user");
        List<Wishlists> wishlists = user.getWishlistsList();
        
        if (request.getParameter("edit") != null) {
            ArrayList<Integer> deletes = new ArrayList<Integer>();
            HashMap<Integer, Integer> prices = new HashMap<Integer, Integer>();
            HashMap<Integer, Integer> semesters = new HashMap<Integer, Integer>();

            for (int i = wishlists.size() - 1; i >= 0; i--) {
                Wishlists wishlist = wishlists.get(i);
                if (request.getParameter("delete" + wishlist.getId()) != null)
                    deletes.add(wishlist.getId());
                else {
                    prices.put(wishlist.getId(), Integer.parseInt(request.getParameter("price" + wishlist.getId())));
                    semesters.put(wishlist.getId(), Integer.parseInt(request.getParameter("semester" + wishlist.getId())));
                }
            }
            if ((new BookTiesDB()).editWishlist(user, deletes, prices, semesters)) {
                request.setAttribute("goodMessage", "Changes saved");
                getServletContext().getRequestDispatcher("/my/wishlist.jsp").forward(request, response);
            } else {
                request.setAttribute("badMessage", "Error saving changes");
                getServletContext().getRequestDispatcher("/my/wishlist-edit.jsp").forward(request, response);
            }
        } else if (request.getParameter("add") != null) {
            // not supported
            BookTiesDB db = new BookTiesDB();
            Books book = db.getBookById(Integer.parseInt(request.getParameter("isbn")));
            if (book == null)
                response.sendRedirect("home.jsp");
            int price = Integer.parseInt(request.getParameter("price"));
            int semester = Integer.parseInt(request.getParameter("semester"));
            if (price < 0 || !SemesterUtil.isValid(semester) || !db.addToWishlist(user, book, price, semester)) {
                request.setAttribute("badMessage", "Error, the book may already be in your wishlist");
                getServletContext().getRequestDispatcher("/my/wishlist-add.jsp?isbn=" + book.getId()).forward(request, response);
            } else {
                request.setAttribute("goodMessage", "Book added");
                getServletContext().getRequestDispatcher("/my/wishlist.jsp").forward(request, response);
            }
            
        } else {
            response.sendRedirect("home.jsp");
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
