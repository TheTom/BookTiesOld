/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servlet.my;

import business.Meetups;
import business.Users;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.BookTiesDB;
import util.SessionUtil;

/**
 *
 * @author Kristopher Windsor
 */
public class MeetupsEditServlet extends HttpServlet {

    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("home.jsp");
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        if (SessionUtil.requireLogin(request, response))
            return;

        Users user = (Users) request.getAttribute("user");
        BookTiesDB btdb = new BookTiesDB();
        List<Meetups> meetups = btdb.getMeetupsByUser(user);
        meetups.addAll(btdb.getMeetupsBySeller(user));
        ArrayList<Integer> deletes = new ArrayList<Integer>();
        HashMap<Integer, Integer> prices = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> semesters = new HashMap<Integer, Integer>();
        HashMap<Integer, String> states = new HashMap<Integer, String>();
        HashMap<Integer, String> comments = new HashMap<Integer, String>();

        for (int i = meetups.size() - 1; i >= 0; i--) {
            Meetups meetup = meetups.get(i);
            if (request.getParameter("delete" + meetup.getId()) != null)
                deletes.add(meetup.getId());
            else {
                String price = request.getParameter("price" + meetup.getId());
                prices.put(meetup.getId(), Integer.parseInt(price));
                semesters.put(meetup.getId(), Integer.parseInt(request.getParameter("semester" + meetup.getId())));
                states.put(meetup.getId(), (String)request.getParameter("state"));
                comments.put(meetup.getId(), (String)request.getParameter("addcomments"));
            }
        }
        if ((new BookTiesDB()).editMeetups(user, deletes, prices, semesters, 
                states, comments)) {
            request.setAttribute("goodMessage", "Changes saved");
            getServletContext().getRequestDispatcher("/my/meetups.jsp").forward(request, response);
        } else {
            request.setAttribute("badMessage", "Error saving changes");
            getServletContext().getRequestDispatcher("/my/meetups-edit.jsp").forward(request, response);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
