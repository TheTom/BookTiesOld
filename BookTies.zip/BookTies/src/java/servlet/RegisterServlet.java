package servlet;

import business.Universities;
import java.util.Date;
import java.util.HashMap;
import util.BookTiesDB;
import business.Users;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import util.SessionUtil;

/**
 *
 * @author joe
 */
public class RegisterServlet extends HttpServlet {

    private BookTiesDB btdb;
    private HashMap<String, String> params;
    
    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("home.jsp");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        btdb = new BookTiesDB();
        params = new HashMap<String, String>();

        SessionUtil.persistLogin(request, response);

        params.put("ruser", request.getParameter("ruser"));
        params.put("email", request.getParameter("email"));
        params.put("address", request.getParameter("address"));
        params.put("phone", request.getParameter("phone"));
        params.put("university", request.getParameter("university"));
        params.put("rpwd", request.getParameter("rpwd"));
        params.put("rpwd2", request.getParameter("rpwd2"));
        
        for (String s : params.keySet())
            if (params.get(s).isEmpty()) {
                request.setAttribute("badMessage", "Please fill out fields");
                getServletContext().getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }

        try {
            String vm = formValidationMessage(params);
            if (vm != null)
                throw new Exception(vm);

            MessageDigest md;
            md = MessageDigest.getInstance("SHA-256");
            md.update(params.get("rpwd").getBytes());
            String mpwd = asHex(md.digest());
            Users user = new Users(
                params.get("ruser"),
                mpwd,
                params.get("email"),
                params.get("phone"),
                params.get("address"),
                new Date()
            );

            Universities uni = btdb.getUniversityById(Integer.parseInt(params.get("university")));
            if (uni == null)
                throw new Exception("Invalid university specified");
            user.setUniversities(uni);

            btdb.registerUser(user);
            request.setAttribute("goodMessage", "You have been registered");
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("badMessage", e.getMessage());
            getServletContext().getRequestDispatcher("/register.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private String formValidationMessage(HashMap<String, String> params) {
        if (!params.get("rpwd").equals(params.get("rpwd2")))
            return "Passwords do not match";
        if (btdb.getUserByName(params.get("ruser")) != null)
            return "Username is already used";
        if (btdb.getUserByEmail(params.get("email")) != null)
            return "Email is already used";
        return null;
    }

    private String asHex(byte[] buf) {
        StringBuilder builder = new StringBuilder(buf.length * 2);
        for (int i = 0; i < buf.length; i++) {
            if (((int) buf[i] & 0xff) < 0x10) {
                builder.append("0");
            }
            builder.append(Long.toString((int) buf[i] & 0xff, 16));
        }
        return builder.toString();
    }

}
