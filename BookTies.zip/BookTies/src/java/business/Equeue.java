/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Boss
 */
@Entity
@Table(name = "equeue", catalog = "booktiesdb", schema = "")
@NamedQueries({
    @NamedQuery(name = "Equeue.findAll", query = "SELECT e FROM Equeue e"),
    @NamedQuery(name = "Equeue.findById", query = "SELECT e FROM Equeue e WHERE e.id = :id"),
    @NamedQuery(name = "Equeue.findBySendnow", query = "SELECT e FROM Equeue e WHERE e.sendnow = :sendnow"),
    @NamedQuery(name = "Equeue.findByCheckTable", query = "SELECT e FROM Equeue e WHERE e.checkTable = :checkTable"),
    @NamedQuery(name = "Equeue.findByCheckId", query = "SELECT e FROM Equeue e WHERE e.checkId = :checkId"),
    @NamedQuery(name = "Equeue.findByCheckKey", query = "SELECT e FROM Equeue e WHERE e.checkKey = :checkKey"),
    @NamedQuery(name = "Equeue.findByCheckValue", query = "SELECT e FROM Equeue e WHERE e.checkValue = :checkValue")})
public class Equeue implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Lob
    @Column(name = "message")
    private String message;
    @Basic(optional = false)
    @Column(name = "sendnow")
    private boolean sendnow;
    @Basic(optional = false)
    @Column(name = "check_table")
    private String checkTable;
    @Basic(optional = false)
    @Column(name = "check_id")
    private int checkId;
    @Basic(optional = false)
    @Column(name = "check_key")
    private String checkKey;
    @Basic(optional = false)
    @Column(name = "check_value")
    private String checkValue;
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Users users;

    public Equeue() {
    }

    public Equeue(Integer id) {
        this.id = id;
    }

    public Equeue(Integer id, String message, boolean sendnow, String checkTable, int checkId, String checkKey, String checkValue) {
        this.id = id;
        this.message = message;
        this.sendnow = sendnow;
        this.checkTable = checkTable;
        this.checkId = checkId;
        this.checkKey = checkKey;
        this.checkValue = checkValue;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean getSendnow() {
        return sendnow;
    }

    public void setSendnow(boolean sendnow) {
        this.sendnow = sendnow;
    }

    public String getCheckTable() {
        return checkTable;
    }

    public void setCheckTable(String checkTable) {
        this.checkTable = checkTable;
    }

    public int getCheckId() {
        return checkId;
    }

    public void setCheckId(int checkId) {
        this.checkId = checkId;
    }

    public String getCheckKey() {
        return checkKey;
    }

    public void setCheckKey(String checkKey) {
        this.checkKey = checkKey;
    }

    public String getCheckValue() {
        return checkValue;
    }

    public void setCheckValue(String checkValue) {
        this.checkValue = checkValue;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Equeue)) {
            return false;
        }
        Equeue other = (Equeue) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.Equeue[id=" + id + "]";
    }

}
