/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import business.Books;
import util.BookInfo;

/**
 *
 * @author Boss
 */
@Entity
@Table(name = "books", catalog = "booktiesdb", schema = "")
@NamedQueries({
    @NamedQuery(name = "Books.findAll", query = "SELECT b FROM Books b"),
    @NamedQuery(name = "Books.findById", query = "SELECT b FROM Books b WHERE b.id = :id"),
    @NamedQuery(name = "Books.findByAuthor", query = "SELECT b FROM Books b WHERE b.author = :author"),
    @NamedQuery(name = "Books.findByEdition", query = "SELECT b FROM Books b WHERE b.edition = :edition"),
    @NamedQuery(name = "Books.findByValue", query = "SELECT b FROM Books b WHERE b.value = :value")})
public class Books implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Lob
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "author")
    private String author;
    @Basic(optional = false)
    @Column(name = "edition")
    private int edition;
    @Basic(optional = false)
    @Lob
    @Column(name = "img")
    private String img;
    @Basic(optional = false)
    @Column(name = "value")
    private int value;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "books")
    private List<Wishlists> wishlistsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "books")
    private List<Listings> listingsList;

    public Books() {
    }

    public Books(Integer id) {
        this.id = id;
    }

    public Books(Integer id, String name, String author, int edition, String img, int value) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.edition = edition;
        this.img = img;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getEdition() {
        return edition;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public List<Wishlists> getWishlistsList() {
        return wishlistsList;
    }

    public void setWishlistsList(List<Wishlists> wishlistsList) {
        this.wishlistsList = wishlistsList;
    }

    public List<Listings> getListingsList() {
        return listingsList;
    }

    public void setListingsList(List<Listings> listingsList) {
        this.listingsList = listingsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Books)) {
            return false;
        }
        Books other = (Books) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.Books[id=" + id + "]";
    }

    /**
     * Reconstruct the ISBN from the ID
     * http://en.wikipedia.org/wiki/International_Standard_Book_Number#Check_digits
     */
    public String getISBN() {
        String isbn = "000000000" + id;
        int sum = 0;

        isbn = isbn.substring(isbn.length() - 9);
        for (int i = 0; i < 9; i++)
            sum += (10 - i) * (isbn.charAt(i) - '0');
        sum = (11 - (sum % 11)) % 11;

        if (sum == 10)
            return isbn + "X";
        return isbn + sum;
    }

    /**
     * Get the base listing price (very inefficiently)
     * @author Kristopher Windsor
     * return the price of the cheapest listing, or -1 if there is none
     */
    public int getCheapestListing()
    {
        int res = Integer.MAX_VALUE;

        for (Listings listing : this.getListingsList())
            if (listing.getState().equals("listed"))
                res = Math.min(res, listing.getPrice());

        if (res == Integer.MAX_VALUE)
            return -1;
        return res;
    }

    /**
     * Get the base listing price (very inefficiently)
     * @author Kristopher Windsor
     * return the price of the cheapest listing, or -1 if there is none
     */
    public int getCheapestListingForSemester(int semester)
    {
        int res = Integer.MAX_VALUE;

        for (Listings listing : this.getListingsList())
            if (listing.getState().equals("listed") && listing.getSemester() == semester)
                res = Math.min(res, listing.getPrice());

        if (res == Integer.MAX_VALUE)
            return -1;
        return res;
    }

    
    public static List<BookInfo> getAllListings()
    {
        ArrayList<BookInfo> booksFound = new ArrayList<BookInfo>();
        /*
        VolumeFeed vf = searchForBooksWithGoogle(str);//.getEntries();
        for (VolumeEntry ent : vf.getEntries())
        {
            String title = "";
            ArrayList<String> authorNames = new ArrayList<String>();
            ArrayList<String> description = new ArrayList<String>();
            URL pictureURL = null;
            URL googleSite = null;
            String googleId = "";
            String isbn10 = null;
            String isbn13 = null;
            for (Title t : ent.getTitles())
                title += t.getValue() + "\n";
            for (Creator c : ent.getCreators())
                authorNames.add(c.getValue());
            for (Description d : ent.getDescriptions())
                description.add(d.getValue());
            for (Link l : ent.getLinks())
            {
                if (l.getType().equals("image/x-unknown"))
                {
                    try
                    {
                        pictureURL = new URL(l.getHref());
                    }
                    catch (java.net.MalformedURLException e)
                    {
                        pictureURL = null;
                    }
                }
            }
            try
            {
                googleSite = new URL(ent.getHtmlLink().getHref());
            }
            catch (java.net.MalformedURLException e)
            {
                googleSite = null;
            }
            if (ent.getIdentifiers().size() > 0)
            {
                googleId = ent.getIdentifiers().get(0).getValue();
                if (ent.getIdentifiers().size() > 1)
                {
                    if (ent.getIdentifiers().get(1).getValue().substring(0, 5).equals("ISBN:"))
                    {
                        isbn10 = ent.getIdentifiers().get(1).getValue().substring(5);
                    }
                    if (ent.getIdentifiers().size() > 2)
                    {
                        if (ent.getIdentifiers().get(2).getValue().substring(0, 5).equals("ISBN:"))
                        {
                            isbn13 = ent.getIdentifiers().get(2).getValue().substring(5);
                        }
                    }
                }
            }

            if (isbn13 != null && isbn10 != null)
            booksFound.add(new BookInfo(title, authorNames, description, isbn10,
                    isbn13, googleId, pictureURL, googleSite));
        }
         
         */
        return booksFound;
    }
}
