/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Boss
 */
@Entity
@Table(name = "meetups", catalog = "booktiesdb", schema = "")
@NamedQueries({
    @NamedQuery(name = "Meetups.findAll", query = "SELECT m FROM Meetups m"),
    @NamedQuery(name = "Meetups.findByUser", query = "SELECT m FROM Meetups m WHERE m.buyer = :buyer"),
    @NamedQuery(name = "Meetups.findBySeller", query = "SELECT m FROM Meetups m WHERE m.seller = :seller"),
    @NamedQuery(name = "Meetups.findById", query = "SELECT m FROM Meetups m WHERE m.id = :id"),
    @NamedQuery(name = "Meetups.findByState", query = "SELECT m FROM Meetups m WHERE m.state = :state"),
    @NamedQuery(name = "Meetups.findByTime", query = "SELECT m FROM Meetups m WHERE m.time = :time")})
public class Meetups implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "state")
    private String state;
    @Basic(optional = false)
    @Column(name = "time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date time;
    @Basic(optional = false)
    @Lob
    @Column(name = "info")
    private String info;
    @JoinColumn(name = "seller_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Users seller;
    @JoinColumn(name = "buyer_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Users buyer;
    @JoinColumn(name = "listing_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Listings listings;

    public Meetups() {
    }

    public Meetups(Integer id) {
        this.id = id;
    }

    public Meetups(Integer id, String state, Date time, String info) {
        this.id = id;
        this.state = state;
        this.time = time;
        this.info = info;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Users getBuyer() {
        return buyer;
    }

    public void setBuyer(Users buyer) {
        this.buyer = buyer;
    }

    public Users getSeller() {
        return seller;
    }

    public void setSeller(Users seller) {
        this.seller = seller;
    }

    public Listings getListings() {
        return listings;
    }

    public void setListings(Listings listings) {
        this.listings = listings;
    }

    public String getParsedInfo() {
        StringBuilder parsedInfo = new StringBuilder();
        String[] array = info.split(":::");
        for (int i = 0; i < array.length; i++) {
            String[] message = array[i].split("::");
            parsedInfo.append("<p>");
            parsedInfo.append(message[0]);
            parsedInfo.append(": ");
            parsedInfo.append(message[1]);
            parsedInfo.append("</p>");
        }
        return parsedInfo.toString();
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Meetups)) {
            return false;
        }
        Meetups other = (Meetups) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.Meetups[id=" + id + "]";
    }

}
