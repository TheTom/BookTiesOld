/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Boss
 */
@Entity
@Table(name = "users", catalog = "booktiesdb", schema = "")
@NamedQueries({
    @NamedQuery(name = "Users.findAll", query = "SELECT u FROM Users u"),
    @NamedQuery(name = "Users.findById", query = "SELECT u FROM Users u WHERE u.id = :id"),
    @NamedQuery(name = "Users.findByName", query = "SELECT u FROM Users u WHERE u.name = :name"),
    @NamedQuery(name = "Users.findByEmail", query = "SELECT u FROM Users u WHERE u.email = :email"),
    @NamedQuery(name = "Users.findByPhone", query = "SELECT u FROM Users u WHERE u.phone = :phone"),
    @NamedQuery(name = "Users.findByEmailbatching", query = "SELECT u FROM Users u WHERE u.emailbatching = :emailbatching")})
public class Users implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Lob
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @Column(name = "phone")
    private String phone;
    @Basic(optional = false)
    @Lob
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @Column(name = "emailbatching")
    @Temporal(TemporalType.TIMESTAMP)
    private Date emailbatching;
    @JoinColumn(name = "university_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Universities universities;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "users")
    private List<Wishlists> wishlistsList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "users")
    private List<Listings> listingsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "buyer")
    private List<Listings> listingsList1;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "users")
    private List<Equeue> equeueList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "seller")
    private List<Meetups> meetupsListAsSeller;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "buyer")
    private List<Meetups> meetupsListAsBuyer;

    public Users() {
    }

    public Users(Integer id) {
        this.id = id;
    }

    public Users(String name, String password, String email, String phone,
            String address, Date emailbatching) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.emailbatching = emailbatching;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getEmailbatching() {
        return emailbatching;
    }

    public void setEmailbatching(Date emailbatching) {
        this.emailbatching = emailbatching;
    }

    public Universities getUniversities() {
        return universities;
    }

    public void setUniversities(Universities universities) {
        this.universities = universities;
    }

    public List<Wishlists> getWishlistsList() {
        return wishlistsList;
    }

    public void setWishlistsList(List<Wishlists> wishlistsList) {
        this.wishlistsList = wishlistsList;
    }

    public List<Listings> getListingsList() {
        return listingsList;
    }

    public void setListingsList(List<Listings> listingsList) {
        this.listingsList = listingsList;
    }

    public List<Listings> getListingsList1() {
        return listingsList1;
    }

    public void setListingsList1(List<Listings> listingsList1) {
        this.listingsList1 = listingsList1;
    }

    public List<Equeue> getEqueueList() {
        return equeueList;
    }

    public void setEqueueList(List<Equeue> equeueList) {
        this.equeueList = equeueList;
    }

    public List<Meetups> getMeetupsAsSellerList() {
        return meetupsListAsSeller;
    }

    public void setMeetupsAsSellerList(List<Meetups> meetupsList) {
        this.meetupsListAsSeller = meetupsList;
    }

    public List<Meetups> getMeetupsAsBuyerList() {
        return meetupsListAsBuyer;
    }

    public void setMeetupsAsBuyerList(List<Meetups> meetupsList) {
        this.meetupsListAsBuyer = meetupsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Users)) {
            return false;
        }
        Users other = (Users) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.Users[id=" + id + "]";
    }

    public boolean hasBookInWishlist(int bookId) {
        for (Wishlists wishlist : this.getWishlistsList())
            if (wishlist.getBooks().getId() == bookId)
                return true;
        return false;
    }
}
