/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import business.Books;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Boss
 */
@Entity
@Table(name = "wishlists", catalog = "booktiesdb", schema = "")
@NamedQueries({
    @NamedQuery(name = "Wishlists.findAll", query = "SELECT w FROM Wishlists w"),
    @NamedQuery(name = "Wishlists.findById", query = "SELECT w FROM Wishlists w WHERE w.id = :id"),
    @NamedQuery(name = "Wishlists.findByPrice", query = "SELECT w FROM Wishlists w WHERE w.price = :price"),
    @NamedQuery(name = "Wishlists.findByPosttime", query = "SELECT w FROM Wishlists w WHERE w.posttime = :posttime"),
    @NamedQuery(name = "Wishlists.findBySemester", query = "SELECT w FROM Wishlists w WHERE w.semester = :semester"),
    @NamedQuery(name = "Wishlists.findByExpiretime", query = "SELECT w FROM Wishlists w WHERE w.expiretime = :expiretime")})
public class Wishlists implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "price")
    private int price;
    @Basic(optional = false)
    @Column(name = "posttime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date posttime;
    @Basic(optional = false)
    @Column(name = "semester")
    private int semester;
    @Basic(optional = false)
    @Column(name = "expiretime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date expiretime;
    @JoinColumn(name = "book_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Books books;
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Users users;

    public Wishlists() {
    }

    public Wishlists(Integer id) {
        this.id = id;
    }

    public Wishlists(Integer id, int price, Date posttime, int semester, Date expiretime) {
        this.id = id;
        this.price = price;
        this.posttime = posttime;
        this.semester = semester;
        this.expiretime = expiretime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Date getPosttime() {
        return posttime;
    }

    public void setPosttime(Date posttime) {
        this.posttime = posttime;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public Date getExpiretime() {
        return expiretime;
    }

    public void setExpiretime(Date expiretime) {
        this.expiretime = expiretime;
    }

    public Books getBooks() {
        return books;
    }

    public void setBooks(Books books) {
        this.books = books;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Wishlists)) {
            return false;
        }
        Wishlists other = (Wishlists) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.Wishlists[id=" + id + "]";
    }

}
