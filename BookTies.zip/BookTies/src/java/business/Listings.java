/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Boss
 */
@Entity
@Table(name = "listings", catalog = "booktiesdb", schema = "")
@NamedQueries({
    @NamedQuery(name = "Listings.findAll", query = "SELECT l FROM Listings l"),
    @NamedQuery(name = "Listings.findById", query = "SELECT l FROM Listings l WHERE l.id = :id"),
    @NamedQuery(name = "Listings.findByBook", query = "SELECT l FROM Listings l WHERE l.books = :books"),
    @NamedQuery(name = "Listings.findByState", query = "SELECT l FROM Listings l WHERE l.state = :state"),
    @NamedQuery(name = "Listings.findByPrice", query = "SELECT l FROM Listings l WHERE l.price = :price"),
    @NamedQuery(name = "Listings.findByPosttime", query = "SELECT l FROM Listings l WHERE l.posttime = :posttime"),
    @NamedQuery(name = "Listings.findBySemester", query = "SELECT l FROM Listings l WHERE l.semester = :semester"),
    @NamedQuery(name = "Listings.findByExpiretime", query = "SELECT l FROM Listings l WHERE l.expiretime = :expiretime")})
public class Listings implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "state")
    private String state;
    @Basic(optional = false)
    @Column(name = "price")
    private int price;
    @Basic(optional = false)
    @Lob
    @Column(name = "info")
    private String info;
    @Basic(optional = false)
    @Column(name = "posttime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date posttime;
    @Basic(optional = false)
    @Column(name = "semester")
    private int semester;
    @Basic(optional = false)
    @Column(name = "expiretime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date expiretime;
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Users users;
    @JoinColumn(name = "book_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Books books;
    @JoinColumn(name = "buyer_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Users buyer;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "listings")
    private List<Meetups> meetupsList;

    public Listings() {
    }

    public Listings(Integer id) {
        this.id = id;
    }

    public Listings(Integer id, String state, int price, String info, Date posttime, int semester, Date expiretime) {
        this.id = id;
        this.state = state;
        this.price = price;
        this.info = info;
        this.posttime = posttime;
        this.semester = semester;
        this.expiretime = expiretime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getPosttime() {
        return posttime;
    }

    public void setPosttime(Date posttime) {
        this.posttime = posttime;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public Date getExpiretime() {
        return expiretime;
    }

    public void setExpiretime(Date expiretime) {
        this.expiretime = expiretime;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Books getBooks() {
        return books;
    }

    public void setBooks(Books books) {
        this.books = books;
    }

    public Users getBuyer() {
        return buyer;
    }

    public void setBuyer(Users buyer) {
        this.buyer = buyer;
    }

    public List<Meetups> getMeetupsList() {
        return meetupsList;
    }

    public void setMeetupsList(List<Meetups> meetupsList) {
        this.meetupsList = meetupsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Listings)) {
            return false;
        }
        Listings other = (Listings) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "data.Listings[id=" + id + "]";
    }

}
